<?php 
session_start();
$_SESSION["b"]=true;
$_SESSION["totale"]=$_POST["totale"];

 ?>